class CSPSolver:
    """Solver untuk Constraint Satisfaction Problem (CSP) menggunakan Backtracking."""

    def __init__(self, variables, domains, constraints):
        """
        Inisialisasi CSP.
        :param variables: Daftar variabel CSP.
        :param domains: Dictionary {variabel: daftar nilai yang memungkinkan}.
        :param constraints: Fungsi yang memeriksa apakah solusi valid.
        """
        self.variables = variables
        self.domains = domains
        self.constraints = constraints
        self.solution = {}

    def is_valid(self, var, value):
        """Memeriksa apakah nilai memenuhi semua batasan."""
        self.solution[var] = value
        for constraint in self.constraints:
            if not constraint(self.solution):
                return False
        return True

    def backtrack(self, assignment={}):
        """Algoritma Backtracking untuk mencari solusi CSP."""
        if len(assignment) == len(self.variables):
            return assignment  # Semua variabel telah terisi

        var = [v for v in self.variables if v not in assignment][0]
        
        for value in self.domains[var]:
            if self.is_valid(var, value):
                assignment[var] = value
                result = self.backtrack(assignment)
                if result:
                    return result
                assignment.pop(var)

        return None  # Jika tidak ada solusi

# Contoh: CSP untuk Sudoku 4x4 sederhana
if __name__ == "__main__":
    variables = ["A1", "A2", "B1", "B2"]  # 4 sel Sudoku
    domains = {var: [1, 2, 3, 4] for var in variables}

    def sudoku_constraints(solution):
        """Pastikan semua nilai unik (contoh sederhana)."""
        return len(set(solution.values())) == len(solution)

    solver = CSPSolver(variables, domains, [sudoku_constraints])
    solution = solver.backtrack()

    if solution:
        print("\n✅ Solusi CSP ditemukan:", solution)
    else:
        print("⚠️ Tidak ada solusi yang ditemukan.")