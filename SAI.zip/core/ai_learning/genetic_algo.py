import random
import numpy as np

class GeneticAlgorithm:
    """Implementasi Genetic Algorithm untuk optimasi solusi."""
    
    def __init__(self, population_size, gene_length, mutation_rate=0.01, generations=100):
        self.population_size = population_size
        self.gene_length = gene_length
        self.mutation_rate = mutation_rate
        self.generations = generations

        # Inisialisasi populasi (array biner)
        self.population = np.random.randint(2, size=(population_size, gene_length))

    def fitness_function(self, individual):
        """Fungsi evaluasi: jumlah '1' dalam individu."""
        return sum(individual)

    def selection(self):
        """Seleksi individu terbaik menggunakan metode turnamen."""
        tournament_size = 3
        selected = []
        for _ in range(self.population_size):
            tournament = random.sample(list(self.population), tournament_size)
            winner = max(tournament, key=self.fitness_function)
            selected.append(winner)
        return np.array(selected)

    def crossover(self, parent1, parent2):
        """Melakukan crossover (reproduksi) antara dua individu."""
        point = random.randint(1, self.gene_length - 1)
        child1 = np.concatenate([parent1[:point], parent2[point:]])
        child2 = np.concatenate([parent2[:point], parent1[point:]])
        return child1, child2

    def mutation(self, individual):
        """Melakukan mutasi pada individu dengan probabilitas tertentu."""
        for i in range(self.gene_length):
            if random.random() < self.mutation_rate:
                individual[i] = 1 - individual[i]  # Flip bit
        return individual

    def evolve(self):
        """Menjalankan proses evolusi selama beberapa generasi."""
        for gen in range(self.generations):
            selected_parents = self.selection()
            next_generation = []

            for i in range(0, self.population_size, 2):
                p1, p2 = selected_parents[i], selected_parents[i + 1]
                c1, c2 = self.crossover(p1, p2)
                next_generation.append(self.mutation(c1))
                next_generation.append(self.mutation(c2))

            self.population = np.array(next_generation)
            best_individual = max(self.population, key=self.fitness_function)
            print(f"🧬 Generasi {gen+1} | Fitness Terbaik: {self.fitness_function(best_individual)}")

        return max(self.population, key=self.fitness_function)

# Contoh Penggunaan Genetic Algorithm
if __name__ == "__main__":
    ga = GeneticAlgorithm(population_size=10, gene_length=8, generations=50)
    best_solution = ga.evolve()
    print("\n🏆 Solusi terbaik yang ditemukan:", best_solution)