import numpy as np
from scipy.optimize import linprog

class LinearProgrammingAI:
    """Menggunakan Linear Programming untuk menyelesaikan masalah optimasi."""

    def __init__(self, objective_coeffs, lhs_constraints, rhs_constraints, bounds):
        self.objective_coeffs = objective_coeffs  # Fungsi tujuan
        self.lhs_constraints = lhs_constraints  # Koefisien batasan (<=)
        self.rhs_constraints = rhs_constraints  # Nilai batasan
        self.bounds = bounds  # Batas nilai variabel

    def solve(self):
        """Menyelesaikan masalah optimasi menggunakan metode Simplex."""
        result = linprog(
            c=self.objective_coeffs,
            A_ub=self.lhs_constraints,
            b_ub=self.rhs_constraints,
            bounds=self.bounds,
            method="highs"
        )
        if result.success:
            return result.x, result.fun  # Return solusi & nilai optimal
        else:
            return None, "⚠️ Solusi tidak ditemukan"

# Contoh Penggunaan
if __name__ == "__main__":
    # Maksimalkan keuntungan: f(x, y) = -3x - 5y
    objective_coeffs = [-3, -5]  # Negatif karena linprog meminimalkan

    # Batasan:
    # 1x + 2y <= 8
    # 3x + 2y <= 12
    lhs_constraints = [[1, 2], [3, 2]]
    rhs_constraints = [8, 12]

    # Batasan variabel: 0 <= x, y <= ∞
    bounds = [(0, None), (0, None)]

    lp = LinearProgrammingAI(objective_coeffs, lhs_constraints, rhs_constraints, bounds)
    solution, optimal_value = lp.solve()

    if solution is not None:
        print("\n🏆 Solusi Optimal Ditemukan:")
        print(f"x = {solution[0]:.2f}, y = {solution[1]:.2f}")
        print(f"🔢 Nilai Optimal: {-optimal_value:.2f}")
    else:
        print(optimal_value)