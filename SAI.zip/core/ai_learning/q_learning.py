import numpy as np
import random

class QLearningAgent:
    """Agen AI yang menggunakan Q-Learning untuk belajar dari pengalaman."""

    def __init__(self, state_size, action_size, learning_rate=0.1, discount_factor=0.9, exploration_rate=1.0, exploration_decay=0.99):
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.exploration_rate = exploration_rate
        self.exploration_decay = exploration_decay
        self.q_table = np.zeros((state_size, action_size))  # Inisialisasi Q-table

    def choose_action(self, state):
        """Memilih aksi berdasarkan eksplorasi atau eksploitasi."""
        if random.uniform(0, 1) < self.exploration_rate:
            return random.randint(0, self.action_size - 1)  # Eksplorasi (random action)
        return np.argmax(self.q_table[state])  # Eksploitasi (memilih aksi terbaik)

    def update_q_table(self, state, action, reward, next_state):
        """Memperbarui Q-table menggunakan formula Q-Learning."""
        best_next_action = np.argmax(self.q_table[next_state])
        td_target = reward + self.discount_factor * self.q_table[next_state, best_next_action]
        td_error = td_target - self.q_table[state, action]
        self.q_table[state, action] += self.learning_rate * td_error

    def decay_exploration(self):
        """Mengurangi tingkat eksplorasi seiring waktu."""
        self.exploration_rate *= self.exploration_decay
        self.exploration_rate = max(self.exploration_rate, 0.01)  # Jangan sampai nol

# Contoh penggunaan Q-Learning dalam lingkungan sederhana
if __name__ == "__main__":
    env_states = 5  # Jumlah state dalam lingkungan
    env_actions = 2  # Jumlah aksi (misal: maju atau mundur)
    episodes = 100

    agent = QLearningAgent(state_size=env_states, action_size=env_actions)

    for episode in range(episodes):
        state = random.randint(0, env_states - 1)  # Memulai dari state acak
        done = False
        
        while not done:
            action = agent.choose_action(state)
            next_state = (state + 1) % env_states  # Transisi sederhana ke state berikutnya
            reward = 1 if next_state == env_states - 1 else -1  # Reward jika mencapai tujuan
            
            agent.update_q_table(state, action, reward, next_state)
            state = next_state

            if state == env_states - 1:  # Berhenti jika mencapai tujuan
                done = True

        agent.decay_exploration()  # Kurangi eksplorasi setelah setiap episode

    print("\n🧠 Q-Table setelah pelatihan:")
    print(agent.q_table)