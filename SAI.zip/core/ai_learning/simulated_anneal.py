import math
import random

class SimulatedAnnealing:
    """Optimasi menggunakan Simulated Annealing."""
    
    def __init__(self, objective_function, initial_solution, temp=1000, cooling_rate=0.99, min_temp=1):
        self.objective_function = objective_function
        self.current_solution = initial_solution
        self.best_solution = initial_solution
        self.temperature = temp
        self.cooling_rate = cooling_rate
        self.min_temp = min_temp

    def generate_neighbor(self, solution):
        """Membuat solusi tetangga dengan sedikit modifikasi."""
        neighbor = solution[:]
        idx = random.randint(0, len(solution) - 1)
        neighbor[idx] += random.uniform(-1, 1)  # Perturbasi kecil
        return neighbor

    def acceptance_probability(self, old_cost, new_cost):
        """Menghitung probabilitas menerima solusi lebih buruk."""
        if new_cost < old_cost:
            return 1.0
        return math.exp((old_cost - new_cost) / self.temperature)

    def optimize(self):
        """Menjalankan proses Simulated Annealing untuk mencari solusi optimal."""
        while self.temperature > self.min_temp:
            new_solution = self.generate_neighbor(self.current_solution)
            old_cost = self.objective_function(self.current_solution)
            new_cost = self.objective_function(new_solution)

            if random.uniform(0, 1) < self.acceptance_probability(old_cost, new_cost):
                self.current_solution = new_solution

            if new_cost < self.objective_function(self.best_solution):
                self.best_solution = new_solution

            self.temperature *= self.cooling_rate  # Turunkan suhu
        
        return self.best_solution

# Contoh Penggunaan
if __name__ == "__main__":
    def objective_function(solution):
        """Fungsi tujuan: mencari nilai minimum dari sum kuadrat."""
        return sum(x ** 2 for x in solution)

    initial_solution = [random.uniform(-10, 10) for _ in range(5)]
    sa = SimulatedAnnealing(objective_function, initial_solution)
    best_solution = sa.optimize()

    print("\n🏆 Solusi terbaik ditemukan:", best_solution)
    print("🔢 Nilai minimum:", objective_function(best_solution))