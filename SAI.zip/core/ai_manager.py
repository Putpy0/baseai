import os
from dotenv import load_dotenv

load_dotenv()

class APIManager:
    """Sistem Rotasi API Key untuk OpenAI, DeepSeek, dan Grok."""

    def __init__(self, service_name):
        """
        Inisialisasi API Manager untuk layanan tertentu (OPENAI, DEEPSEEK, GROK).
        :param service_name: Nama layanan API yang digunakan.
        """
        self.service_name = service_name.upper()  # Pastikan uppercase
        self.max_keys = 10  # Jumlah maksimal API Key per layanan
        self.current_key_index = int(os.getenv(f"CURRENT_{self.service_name}_KEY", 1))

    def get_api_key(self):
        """Mengambil API Key yang sedang aktif untuk layanan tertentu."""
        key = os.getenv(f"{self.service_name}_API_KEY_{self.current_key_index}")
        if key:
            return key
        else:
            print(f"⚠️ API Key {self.service_name} {self.current_key_index} tidak ditemukan. Menggunakan key pertama.")
            return os.getenv(f"{self.service_name}_API_KEY_1")

    def rotate_key(self):
        """Beralih ke API Key berikutnya jika terjadi limit atau error."""
        self.current_key_index += 1
        if self.current_key_index > self.max_keys:
            self.current_key_index = 1  # Kembali ke key pertama jika sudah mencapai batas

        os.environ[f"CURRENT_{self.service_name}_KEY"] = str(self.current_key_index)
        print(f"🔄 Beralih ke API Key {self.service_name} {self.current_key_index}")

        return self.get_api_key()

# Contoh Penggunaan
if __name__ == "__main__":
    openai_manager = APIManager("OPENAI")
    deepseek_manager = APIManager("DEEPSEEK")
    grok_manager = APIManager("GROK")

    print("🔑 OpenAI API Key:", openai_manager.get_api_key())
    print("🔑 DeepSeek API Key:", deepseek_manager.get_api_key())
    print("🔑 Grok API Key:", grok_manager.get_api_key())

    print("🛑 API Key OpenAI habis! Beralih ke yang berikutnya...")
    openai_manager.rotate_key()

    print("🔑 OpenAI API Key (Baru):", openai_manager.get_api_key())