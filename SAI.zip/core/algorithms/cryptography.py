import random
import sympy

class Cryptography:
    """Implementasi algoritma kriptografi: Caesar Cipher & RSA Encryption."""

    @staticmethod
    def caesar_cipher_encrypt(text, shift):
        """Mengenkripsi teks menggunakan Caesar Cipher."""
        result = ""
        for char in text:
            if char.isalpha():
                shift_amount = shift % 26
                new_char = chr(((ord(char.lower()) - ord('a') + shift_amount) % 26) + ord('a'))
                result += new_char.upper() if char.isupper() else new_char
            else:
                result += char
        return result

    @staticmethod
    def caesar_cipher_decrypt(text, shift):
        """Mendekripsi teks yang dienkripsi dengan Caesar Cipher."""
        return Cryptography.caesar_cipher_encrypt(text, -shift)

    @staticmethod
    def generate_rsa_keys():
        """Menghasilkan kunci publik & privat untuk RSA Encryption."""
        p = sympy.randprime(100, 500)
        q = sympy.randprime(100, 500)
        n = p * q
        phi = (p - 1) * (q - 1)

        e = random.choice([x for x in range(2, phi) if sympy.gcd(x, phi) == 1])
        d = pow(e, -1, phi)  # Menghitung kunci privat (modular inverse)

        return {"public_key": (e, n), "private_key": (d, n)}

    @staticmethod
    def rsa_encrypt(plaintext, public_key):
        """Mengenkripsi teks menggunakan RSA Encryption."""
        e, n = public_key
        return [pow(ord(char), e, n) for char in plaintext]

    @staticmethod
    def rsa_decrypt(ciphertext, private_key):
        """Mendekripsi teks terenkripsi RSA."""
        d, n = private_key
        return "".join(chr(pow(char, d, n)) for char in ciphertext)

# Contoh Penggunaan
if __name__ == "__main__":
    text = "HELLO AI"
    shift = 3
    encrypted_text = Cryptography.caesar_cipher_encrypt(text, shift)
    decrypted_text = Cryptography.caesar_cipher_decrypt(encrypted_text, shift)
    
    print("🔒 Caesar Cipher Encrypted:", encrypted_text)
    print("🔓 Caesar Cipher Decrypted:", decrypted_text)

    rsa_keys = Cryptography.generate_rsa_keys()
    rsa_encrypted = Cryptography.rsa_encrypt(text, rsa_keys["public_key"])
    rsa_decrypted = Cryptography.rsa_decrypt(rsa_encrypted, rsa_keys["private_key"])
    
    print("🔒 RSA Encrypted:", rsa_encrypted)
    print("🔓 RSA Decrypted:", rsa_decrypted)