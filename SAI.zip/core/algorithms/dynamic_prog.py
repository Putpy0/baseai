import numpy as np

class DynamicProgramming:
    """Implementasi algoritma Dynamic Programming (DP)."""

    @staticmethod
    def fibonacci_dp(n, memo={}):
        """Menghitung bilangan Fibonacci dengan memoization (Top-Down DP)."""
        if n in memo:
            return memo[n]
        if n <= 1:
            return n
        memo[n] = DynamicProgramming.fibonacci_dp(n - 1, memo) + DynamicProgramming.fibonacci_dp(n - 2, memo)
        return memo[n]

    @staticmethod
    def knapsack(values, weights, capacity):
        """0/1 Knapsack Problem menggunakan Bottom-Up DP."""
        n = len(values)
        dp = np.zeros((n + 1, capacity + 1))

        for i in range(1, n + 1):
            for w in range(capacity + 1):
                if weights[i - 1] <= w:
                    dp[i][w] = max(dp[i - 1][w], values[i - 1] + dp[i - 1][w - weights[i - 1]])
                else:
                    dp[i][w] = dp[i - 1][w]
        
        return dp[n][capacity]

    @staticmethod
    def lcs(str1, str2):
        """Menemukan Longest Common Subsequence (LCS) menggunakan DP."""
        m, n = len(str1), len(str2)
        dp = np.zeros((m + 1, n + 1))

        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if str1[i - 1] == str2[j - 1]:
                    dp[i][j] = dp[i - 1][j - 1] + 1
                else:
                    dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
        
        return int(dp[m][n])

# Contoh Penggunaan
if __name__ == "__main__":
    print("🔢 Fibonacci DP (n=10):", DynamicProgramming.fibonacci_dp(10))
    
    values = [60, 100, 120]
    weights = [10, 20, 30]
    capacity = 50
    print("🎒 Knapsack (capacity=50):", DynamicProgramming.knapsack(values, weights, capacity))
    
    str1 = "AGGTAB"
    str2 = "GXTXAYB"
    print("🔡 LCS dari 'AGGTAB' dan 'GXTXAYB':", DynamicProgramming.lcs(str1, str2))