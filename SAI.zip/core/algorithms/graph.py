import heapq
import math
from collections import deque

class GraphAlgorithms:
    """Implementasi algoritma graf: BFS, DFS, Dijkstra, A* Algorithm."""

    @staticmethod
    def bfs(graph, start):
        """Breadth-First Search (BFS) - O(V + E)"""
        visited = set()
        queue = deque([start])
        result = []

        while queue:
            node = queue.popleft()
            if node not in visited:
                visited.add(node)
                result.append(node)
                queue.extend(graph.get(node, []))
        return result

    @staticmethod
    def dfs(graph, start, visited=None):
        """Depth-First Search (DFS) - O(V + E)"""
        if visited is None:
            visited = set()
        visited.add(start)
        result = [start]

        for neighbor in graph.get(start, []):
            if neighbor not in visited:
                result.extend(GraphAlgorithms.dfs(graph, neighbor, visited))
        return result

    @staticmethod
    def dijkstra(graph, start):
        """Dijkstra’s Algorithm - O((V + E) log V)"""
        pq = []
        distances = {node: math.inf for node in graph}
        distances[start] = 0
        heapq.heappush(pq, (0, start))

        while pq:
            current_distance, current_node = heapq.heappop(pq)

            if current_distance > distances[current_node]:
                continue

            for neighbor, weight in graph[current_node]:
                distance = current_distance + weight

                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    heapq.heappush(pq, (distance, neighbor))

        return distances

    @staticmethod
    def a_star(graph, start, goal, heuristic):
        """A* Algorithm - O((V + E) log V)"""
        pq = []
        g_cost = {node: math.inf for node in graph}
        g_cost[start] = 0
        f_cost = {node: math.inf for node in graph}
        f_cost[start] = heuristic[start]
        heapq.heappush(pq, (f_cost[start], start))

        came_from = {}

        while pq:
            _, current = heapq.heappop(pq)

            if current == goal:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                return path[::-1]

            for neighbor, weight in graph[current]:
                tentative_g_cost = g_cost[current] + weight

                if tentative_g_cost < g_cost[neighbor]:
                    came_from[neighbor] = current
                    g_cost[neighbor] = tentative_g_cost
                    f_cost[neighbor] = tentative_g_cost + heuristic[neighbor]
                    heapq.heappush(pq, (f_cost[neighbor], neighbor))

        return None  # Tidak ada jalur ditemukan

# Contoh Penggunaan
if __name__ == "__main__":
    graph = {
        "A": [("B", 1), ("C", 4)],
        "B": [("A", 1), ("C", 2), ("D", 5)],
        "C": [("A", 4), ("B", 2), ("D", 1)],
        "D": [("B", 5), ("C", 1)]
    }

    heuristic = {"A": 3, "B": 2, "C": 1, "D": 0}  # Estimasi ke "D"

    print("🔄 BFS:", GraphAlgorithms.bfs(graph, "A"))
    print("🔄 DFS:", GraphAlgorithms.dfs(graph, "A"))
    print("🔄 Dijkstra:", GraphAlgorithms.dijkstra(graph, "A"))
    print("🔄 A* Algorithm:", GraphAlgorithms.a_star(graph, "A", "D", heuristic))