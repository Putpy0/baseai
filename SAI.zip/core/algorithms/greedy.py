import heapq

class GreedyAlgorithms:
    """Implementasi algoritma Greedy: Huffman Coding, Prim’s, Kruskal’s Algorithm."""

    class HuffmanNode:
        """Node untuk Huffman Tree."""
        def __init__(self, char, freq):
            self.char = char
            self.freq = freq
            self.left = None
            self.right = None

        def __lt__(self, other):
            return self.freq < other.freq

    @staticmethod
    def huffman_encoding(frequencies):
        """Membuat Huffman Tree dan mengembalikan kode Huffman."""
        heap = [GreedyAlgorithms.HuffmanNode(char, freq) for char, freq in frequencies.items()]
        heapq.heapify(heap)

        while len(heap) > 1:
            left = heapq.heappop(heap)
            right = heapq.heappop(heap)
            merged = GreedyAlgorithms.HuffmanNode(None, left.freq + right.freq)
            merged.left, merged.right = left, right
            heapq.heappush(heap, merged)

        huffman_codes = {}

        def generate_codes(node, current_code=""):
            if node:
                if node.char:
                    huffman_codes[node.char] = current_code
                generate_codes(node.left, current_code + "0")
                generate_codes(node.right, current_code + "1")

        generate_codes(heap[0])
        return huffman_codes

    @staticmethod
    def prim(graph):
        """Prim’s Algorithm - Minimum Spanning Tree (O(E log V))."""
        start_node = next(iter(graph))
        visited = set()
        min_heap = [(0, start_node)]
        mst = []
        
        while min_heap:
            weight, node = heapq.heappop(min_heap)
            if node not in visited:
                visited.add(node)
                mst.append((node, weight))

                for neighbor, cost in graph[node]:
                    if neighbor not in visited:
                        heapq.heappush(min_heap, (cost, neighbor))

        return mst

    @staticmethod
    def kruskal(edges, num_nodes):
        """Kruskal’s Algorithm - Minimum Spanning Tree (O(E log E))."""
        edges.sort(key=lambda x: x[2])  # Urutkan berdasarkan bobot
        parent = list(range(num_nodes))
        
        def find(node):
            while node != parent[node]:
                node = parent[node]
            return node

        mst = []
        for u, v, weight in edges:
            root_u = find(u)
            root_v = find(v)

            if root_u != root_v:
                mst.append((u, v, weight))
                parent[root_u] = root_v

        return mst

# Contoh Penggunaan
if __name__ == "__main__":
    frequencies = {"A": 5, "B": 9, "C": 12, "D": 13, "E": 16, "F": 45}
    print("🗜 Huffman Encoding:", GreedyAlgorithms.huffman_encoding(frequencies))

    graph = {
        "A": [("B", 1), ("C", 4)],
        "B": [("A", 1), ("C", 2), ("D", 5)],
        "C": [("A", 4), ("B", 2), ("D", 1)],
        "D": [("B", 5), ("C", 1)]
    }
    print("🌉 Prim’s MST:", GreedyAlgorithms.prim(graph))

    edges = [(0, 1, 10), (0, 2, 6), (0, 3, 5), (1, 3, 15), (2, 3, 4)]
    print("🌉 Kruskal’s MST:", GreedyAlgorithms.kruskal(edges, 4))