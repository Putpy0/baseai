import numpy as np
from collections import Counter
from sklearn.tree import DecisionTreeClassifier

class MachineLearningAlgorithms:
    """Implementasi algoritma dasar Machine Learning: Linear Regression, KNN, Decision Tree."""

    @staticmethod
    def linear_regression(X, y):
        """Menerapkan Linear Regression menggunakan Least Squares Method."""
        X = np.c_[np.ones(X.shape[0]), X]  # Tambahkan bias (x0 = 1)
        theta = np.linalg.inv(X.T @ X) @ X.T @ y  # Rumus regresi linier
        return theta  # Mengembalikan koefisien regresi

    @staticmethod
    def knn_classify(X_train, y_train, X_test, k=3):
        """K-Nearest Neighbors (KNN) untuk klasifikasi."""
        predictions = []
        for test_point in X_test:
            distances = [np.linalg.norm(train_point - test_point) for train_point in X_train]
            nearest_indices = np.argsort(distances)[:k]
            nearest_labels = [y_train[i] for i in nearest_indices]
            predictions.append(Counter(nearest_labels).most_common(1)[0][0])
        return predictions

    @staticmethod
    def decision_tree_classify(X_train, y_train, X_test):
        """Decision Tree Classifier menggunakan Scikit-Learn."""
        model = DecisionTreeClassifier()
        model.fit(X_train, y_train)
        return model.predict(X_test)

# Contoh Penggunaan
if __name__ == "__main__":
    # Contoh dataset untuk Linear Regression
    X = np.array([[1], [2], [3], [4], [5]])
    y = np.array([2, 4, 6, 8, 10])  # y = 2x (garis lurus)
    theta = MachineLearningAlgorithms.linear_regression(X, y)
    print("📈 Linear Regression Coefficients:", theta)

    # Contoh dataset untuk KNN
    X_train = np.array([[1, 2], [2, 3], [3, 4], [5, 6]])
    y_train = ["A", "A", "B", "B"]
    X_test = np.array([[3, 3], [4, 5]])
    knn_result = MachineLearningAlgorithms.knn_classify(X_train, y_train, X_test, k=3)
    print("📊 KNN Classification:", knn_result)

    # Contoh dataset untuk Decision Tree
    tree_result = MachineLearningAlgorithms.decision_tree_classify(X_train, y_train, X_test)
    print("🌳 Decision Tree Classification:", tree_result)