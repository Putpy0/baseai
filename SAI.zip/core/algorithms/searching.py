class SearchingAlgorithms:
    """Implementasi algoritma pencarian: Linear Search & Binary Search."""

    @staticmethod
    def linear_search(arr, target):
        """Mencari elemen dalam array menggunakan Linear Search."""
        for index, value in enumerate(arr):
            if value == target:
                return index  # Mengembalikan indeks elemen
        return -1  # Tidak ditemukan

    @staticmethod
    def binary_search(arr, target):
        """Mencari elemen dalam array menggunakan Binary Search (harus terurut)."""
        left, right = 0, len(arr) - 1

        while left <= right:
            mid = (left + right) // 2
            if arr[mid] == target:
                return mid
            elif arr[mid] < target:
                left = mid + 1
            else:
                right = mid - 1

        return -1  # Tidak ditemukan

# Contoh Penggunaan
if __name__ == "__main__":
    data = [3, 1, 7, 5, 9, 2, 8]
    sorted_data = sorted(data)

    print("🔍 Linear Search:", SearchingAlgorithms.linear_search(data, 5))  # Harus menemukan indeks
    print("🔍 Binary Search:", SearchingAlgorithms.binary_search(sorted_data, 5))  # Harus menemukan indeks