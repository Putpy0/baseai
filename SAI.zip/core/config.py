import os
from dotenv import load_dotenv

# Load .env file
load_dotenv()

class Config:
    """Konfigurasi utama SAI: API, Database, dan Preferensi Sistem."""
    
    # API Keys (diambil dari .env)
    OPENAI_KEYS = os.getenv("OPENAI_KEYS", "").split(",")
    DEEPSEEK_KEYS = os.getenv("DEEPSEEK_KEYS", "").split(",")
    GROK_KEYS = os.getenv("GROK_KEYS", "").split(",")

    # URL untuk mengecek status API
    API_PROVIDERS = {
        "openai": {
            "status_check_url": "https://api.openai.com/v1/models"
        },
        "deepseek": {
            "status_check_url": "https://api.deepseek.com/v1/models"
        },
        "grok": {
            "status_check_url": "https://api.grok.com/v1/models"
        }
    }

    # Database Configuration
    DATABASE_PATH = "storage/knowledge.db"

    # Search Configuration
    GOOGLE_SEARCH_ENABLED = True
    SEARCH_RESULT_LIMIT = 5

    # Auto-Training Settings
    AUTO_TRAINING_ENABLED = True
    TRAINING_INTERVAL_HOURS = 24
    TRAINING_TOPICS = ["AI", "Teknologi", "Ekonomi", "Crypto"]

    # Logging
    LOGGING_ENABLED = True
    LOG_FILE = "storage/logs/sai_log.txt"

# Contoh penggunaan
if __name__ == "__main__":
    print("🔧 Konfigurasi AI:")
    print(f"✅ OpenAI Keys: {Config.OPENAI_KEYS}")
    print(f"✅ Database Path: {Config.DATABASE_PATH}")
    print(f"✅ Google Search Enabled: {Config.GOOGLE_SEARCH_ENABLED}")