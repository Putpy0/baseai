import math

class AlphaBetaPruning:
    """Implementasi Alpha-Beta Pruning untuk optimasi Minimax."""

    def __init__(self, depth=3):
        self.depth = depth

    def minimax(self, state, depth, alpha, beta, is_maximizing):
        """Algoritma Minimax dengan Alpha-Beta Pruning."""
        if self.is_terminal(state) or depth == 0:
            return self.evaluate(state)

        if is_maximizing:
            best_score = -math.inf
            for move in self.get_possible_moves(state):
                new_state = self.make_move(state, move, "X")
                score = self.minimax(new_state, depth - 1, alpha, beta, False)
                best_score = max(best_score, score)
                alpha = max(alpha, best_score)
                if beta <= alpha:  # Pruning
                    break
            return best_score
        else:
            best_score = math.inf
            for move in self.get_possible_moves(state):
                new_state = self.make_move(state, move, "O")
                score = self.minimax(new_state, depth - 1, alpha, beta, True)
                best_score = min(best_score, score)
                beta = min(beta, best_score)
                if beta <= alpha:  # Pruning
                    break
            return best_score

    def get_best_move(self, state):
        """Mencari langkah terbaik untuk AI menggunakan Alpha-Beta Pruning."""
        best_move = None
        best_score = -math.inf

        for move in self.get_possible_moves(state):
            new_state = self.make_move(state, move, "X")
            score = self.minimax(new_state, self.depth - 1, -math.inf, math.inf, False)
            if score > best_score:
                best_score = score
                best_move = move

        return best_move

    def is_terminal(self, state):
        """Memeriksa apakah game sudah selesai (implementasi tergantung game)."""
        return all(cell != " " for row in state for cell in row)

    def evaluate(self, state):
        """Menghitung skor board untuk AI (implementasi tergantung game)."""
        return 0  # Placeholder (bisa diubah sesuai aturan game)

    def get_possible_moves(self, state):
        """Mengembalikan daftar langkah yang bisa diambil AI."""
        return [(i, j) for i in range(len(state)) for j in range(len(state[i])) if state[i][j] == " "]

    def make_move(self, state, move, player):
        """Membuat langkah baru dalam game."""
        new_state = [row[:] for row in state]
        new_state[move[0]][move[1]] = player
        return new_state

# Contoh Penggunaan dengan Tic-Tac-Toe
if __name__ == "__main__":
    initial_state = [
        ["X", "O", " "],
        [" ", "X", " "],
        ["O", " ", " "]
    ]

    ai = AlphaBetaPruning(depth=3)
    best_move = ai.get_best_move(initial_state)

    print("🎮 Langkah terbaik untuk AI (Alpha-Beta Pruning):", best_move)