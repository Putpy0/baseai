class BayesianInference:
    """Implementasi Bayesian Inference untuk pengambilan keputusan berbasis probabilitas."""

    def __init__(self, prior_prob):
        """
        Inisialisasi dengan probabilitas awal (prior).
        :param prior_prob: Dictionary {hipotesis: probabilitas awal}.
        """
        self.prior_prob = prior_prob

    def update_posterior(self, likelihoods, evidence_prob):
        """
        Menghitung posterior probability menggunakan Teorema Bayes.
        :param likelihoods: Dictionary {hipotesis: P(evidence|hipotesis)}.
        :param evidence_prob: P(evidence) atau bisa dihitung dari total probabilitas.
        """
        posterior_prob = {}
        for hypothesis, prior in self.prior_prob.items():
            posterior_prob[hypothesis] = (likelihoods[hypothesis] * prior) / evidence_prob
        return posterior_prob

    def calculate_evidence(self, likelihoods):
        """
        Menghitung P(evidence) dengan total probability theorem.
        :param likelihoods: Dictionary {hipotesis: P(evidence|hipotesis)}.
        """
        return sum(likelihoods[hyp] * self.prior_prob[hyp] for hyp in self.prior_prob)

# Contoh Penggunaan
if __name__ == "__main__":
    # Probabilitas awal (Prior)
    prior = {"Spam": 0.3, "Not Spam": 0.7}

    # Probabilitas bukti diberikan hipotesis (Likelihood)
    likelihood = {"Spam": 0.8, "Not Spam": 0.2}

    # Hitung probabilitas bukti (Evidence)
    bayes = BayesianInference(prior)
    evidence = bayes.calculate_evidence(likelihood)

    # Hitung probabilitas posterior
    posterior = bayes.update_posterior(likelihood, evidence)

    print("📊 Posterior Probabilities (Setelah Bukti Baru):", posterior)