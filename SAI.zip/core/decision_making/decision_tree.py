from collections import Counter
import numpy as np

class DecisionTree:
    """Implementasi Decision Tree sederhana untuk AI Decision Making."""

    def __init__(self, max_depth=None):
        self.max_depth = max_depth
        self.tree = None

    def fit(self, X, y):
        """Membangun Decision Tree berdasarkan data training."""
        self.tree = self._build_tree(X, y, depth=0)

    def _build_tree(self, X, y, depth):
        """Rekursif membangun Decision Tree."""
        if len(set(y)) == 1:
            return y[0]
        if self.max_depth and depth >= self.max_depth:
            return Counter(y).most_common(1)[0][0]

        best_feature = self._find_best_split(X, y)
        if best_feature is None:
            return Counter(y).most_common(1)[0][0]

        tree = {}
        unique_values = set(X[:, best_feature])
        for value in unique_values:
            X_subset, y_subset = self._split_data(X, y, best_feature, value)
            tree[(best_feature, value)] = self._build_tree(X_subset, y_subset, depth + 1)

        return tree

    def _find_best_split(self, X, y):
        """Menentukan fitur terbaik untuk membagi data berdasarkan informasi gain."""
        num_features = X.shape[1]
        best_feature, best_gain = None, 0

        for feature in range(num_features):
            gain = self._information_gain(X, y, feature)
            if gain > best_gain:
                best_feature, best_gain = feature, gain

        return best_feature

    def _information_gain(self, X, y, feature):
        """Menghitung informasi gain untuk suatu fitur."""
        entropy_before = self._entropy(y)
        values = set(X[:, feature])
        entropy_after = sum(
            (np.sum(X[:, feature] == value) / len(y)) * self._entropy(y[X[:, feature] == value])
            for value in values
        )
        return entropy_before - entropy_after

    def _entropy(self, y):
        """Menghitung entropi dari distribusi label."""
        counts = Counter(y)
        probabilities = [count / len(y) for count in counts.values()]
        return -sum(p * np.log2(p) for p in probabilities)

    def _split_data(self, X, y, feature, value):
        """Memisahkan data berdasarkan nilai fitur tertentu."""
        mask = X[:, feature] == value
        return X[mask], y[mask]

    def predict(self, X):
        """Memprediksi hasil berdasarkan Decision Tree yang telah dilatih."""
        return [self._predict_sample(sample, self.tree) for sample in X]

    def _predict_sample(self, sample, tree):
        """Menelusuri pohon keputusan untuk satu sampel data."""
        if not isinstance(tree, dict):
            return tree
        for (feature, value), subtree in tree.items():
            if sample[feature] == value:
                return self._predict_sample(sample, subtree)
        return None  # Jika tidak ditemukan, return None

# Contoh Penggunaan
if __name__ == "__main__":
    # Dataset contoh (fitur biner)
    X = np.array([
        [1, 0, 1], [0, 1, 0], [1, 1, 1], [0, 0, 0], [1, 0, 0]
    ])
    y = np.array(["Ya", "Tidak", "Ya", "Tidak", "Ya"])

    tree = DecisionTree(max_depth=3)
    tree.fit(X, y)

    test_sample = np.array([[1, 1, 0]])
    print("🌳 Prediksi Decision Tree:", tree.predict(test_sample))