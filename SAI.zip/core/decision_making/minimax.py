import math

class MinimaxAlgorithm:
    """Implementasi Minimax Algorithm untuk AI Game Strategy."""

    def __init__(self, depth=3):
        self.depth = depth

    def minimax(self, state, depth, is_maximizing):
        """Algoritma Minimax untuk memilih langkah terbaik."""
        if self.is_terminal(state) or depth == 0:
            return self.evaluate(state)

        if is_maximizing:
            best_score = -math.inf
            for move in self.get_possible_moves(state):
                new_state = self.make_move(state, move)
                score = self.minimax(new_state, depth - 1, False)
                best_score = max(best_score, score)
            return best_score
        else:
            best_score = math.inf
            for move in self.get_possible_moves(state):
                new_state = self.make_move(state, move)
                score = self.minimax(new_state, depth - 1, True)
                best_score = min(best_score, score)
            return best_score

    def get_best_move(self, state):
        """Mencari langkah terbaik untuk AI."""
        best_move = None
        best_score = -math.inf

        for move in self.get_possible_moves(state):
            new_state = self.make_move(state, move)
            score = self.minimax(new_state, self.depth - 1, False)
            if score > best_score:
                best_score = score
                best_move = move

        return best_move

    def is_terminal(self, state):
        """Memeriksa apakah game sudah selesai (implementasi tergantung game)."""
        return all(cell != " " for row in state for cell in row)

    def evaluate(self, state):
        """Menghitung skor board untuk AI (implementasi tergantung game)."""
        return 0  # Placeholder (diubah sesuai aturan game)

    def get_possible_moves(self, state):
        """Mengembalikan daftar langkah yang bisa diambil AI."""
        return [(i, j) for i in range(len(state)) for j in range(len(state[i])) if state[i][j] == " "]

    def make_move(self, state, move):
        """Membuat langkah baru dalam game."""
        new_state = [row[:] for row in state]
        new_state[move[0]][move[1]] = "X"  # AI selalu bermain sebagai "X"
        return new_state

# Contoh Penggunaan dengan Tic-Tac-Toe
if __name__ == "__main__":
    initial_state = [
        ["X", "O", " "],
        [" ", "X", " "],
        ["O", " ", " "]
    ]

    minimax_ai = MinimaxAlgorithm(depth=3)
    best_move = minimax_ai.get_best_move(initial_state)
    
    print("🎮 Langkah terbaik untuk AI:", best_move)