import sqlite3

class KnowledgeBase:
    """Sistem penyimpanan & pengambilan data AI (SQLite)."""

    def __init__(self, db_path="storage/knowledge.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.create_table()

    def create_table(self):
        """Membuat tabel jika belum ada."""
        query = """CREATE TABLE IF NOT EXISTS knowledge (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT UNIQUE,
            answer TEXT
        )"""
        self.conn.execute(query)
        self.conn.commit()

    def search_knowledge(self, question):
        """Mencari jawaban di Knowledge Base berdasarkan pertanyaan."""
        query = "SELECT answer FROM knowledge WHERE question = ?"
        cursor = self.conn.execute(query, (question,))
        row = cursor.fetchone()
        return row[0] if row else None

    def save_knowledge(self, question, answer):
        """Menyimpan jawaban ke Knowledge Base."""
        query = "INSERT INTO knowledge (question, answer) VALUES (?, ?)"
        try:
            self.conn.execute(query, (question, answer))
            self.conn.commit()
        except sqlite3.IntegrityError:
            pass  # Jika pertanyaan sudah ada, tidak perlu disimpan ulang