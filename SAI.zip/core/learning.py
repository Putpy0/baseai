import time
import requests
from bs4 import BeautifulSoup
from core.knowledge import KnowledgeBase

class AILearning:
    """Modul Auto-Training AI untuk belajar dari data baru."""

    def __init__(self):
        self.knowledge_base = KnowledgeBase()

    def fetch_news_data(self, keyword):
        """Mengambil berita terbaru terkait keyword menggunakan Google News."""
        url = f"https://news.google.com/search?q={keyword}"
        headers = {"User-Agent": "Mozilla/5.0"}
        
        try:
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                return self.extract_news(response.text)
        except requests.RequestException as e:
            print(f"⚠️ Gagal mengambil berita: {e}")
        
        return []

    def extract_news(self, html):
        """Mengolah hasil pencarian Google News untuk mendapatkan ringkasan berita."""
        soup = BeautifulSoup(html, "html.parser")
        news_items = []
        
        for item in soup.find_all("h3"):
            title = item.text
            link = item.a["href"] if item.a else ""
            if title and link:
                news_items.append(f"{title} - {link}")

        return news_items[:5]  # Ambil 5 berita terbaru

    def update_knowledge_from_news(self, topic):
        """Mempelajari berita terbaru dan menyimpannya dalam Knowledge Base."""
        news = self.fetch_news_data(topic)
        if not news:
            return "Tidak ada berita terbaru untuk topik ini."

        summary = "\n".join(news)
        self.knowledge_base.save_knowledge(topic, summary)
        return f"✅ AI telah belajar dari berita terbaru tentang: {topic}"

    def learn_from_document(self, file_path):
        """Mempelajari dokumen yang diunggah user (TXT atau PDF)."""
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                content = file.read()
                self.knowledge_base.save_knowledge(f"Dokumen: {file_path}", content)
                return f"✅ AI telah belajar dari dokumen: {file_path}"
        except Exception as e:
            return f"⚠️ Gagal membaca dokumen: {e}"

    def auto_training(self):
        """AI secara otomatis belajar dari berita populer setiap 24 jam."""
        topics = ["AI", "Teknologi", "Ekonomi", "Crypto"]
        
        while True:
            print("\n🔄 Memulai sesi auto-training AI...")
            for topic in topics:
                print(self.update_knowledge_from_news(topic))
            
            print("⏳ Menunggu 24 jam sebelum sesi training berikutnya...")
            time.sleep(86400)  # Tidur selama 24 jam

# Contoh penggunaan manual
if __name__ == "__main__":
    ai_learning = AILearning()
    topic = input("📢 Masukkan topik untuk dipelajari AI: ")
    print(ai_learning.update_knowledge_from_news(topic))