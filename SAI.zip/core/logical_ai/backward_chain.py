class BackwardChaining:
    """Implementasi Backward Chaining untuk Sistem Pakar AI."""

    def __init__(self, rules):
        """
        Inisialisasi dengan aturan berbentuk {kesimpulan: if_conditions}.
        :param rules: Dictionary {kesimpulan: set(if_conditions)}
        """
        self.rules = rules

    def infer(self, goal, known_facts):
        """
        Menjalankan backward chaining untuk mencari apakah suatu kesimpulan bisa dibuktikan.
        :param goal: Kesimpulan yang ingin dicapai.
        :param known_facts: Fakta-fakta yang diketahui.
        :return: True jika kesimpulan bisa dibuktikan, False jika tidak.
        """
        if goal in known_facts:
            return True
        if goal not in self.rules:
            return False

        for condition_set in self.rules[goal]:
            if all(self.infer(condition, known_facts) for condition in condition_set):
                return True

        return False

# Contoh Penggunaan
if __name__ == "__main__":
    # Aturan sistem pakar dalam bentuk {kesimpulan: [set(fakta yang diperlukan)]}
    rules = {
        "Flu": [{"Demam", "Batuk"}],
        "Infeksi Virus": [{"Flu", "Sakit Kepala"}],
        "Alergi": [{"Bersin", "Mata Berair"}]
    }

    # Fakta awal
    known_facts = {"Demam", "Batuk", "Sakit Kepala"}

    # Inisialisasi Backward Chaining
    bc = BackwardChaining(rules)
    goal = "Infeksi Virus"

    # AI mencoba membuktikan apakah "Infeksi Virus" benar berdasarkan fakta yang diketahui
    result = bc.infer(goal, known_facts)

    print(f"🔍 Apakah '{goal}' bisa dibuktikan berdasarkan fakta? {'✅ Ya' if result else '❌ Tidak'}")