class ForwardChaining:
    """Implementasi Forward Chaining untuk Sistem Pakar AI."""

    def __init__(self, rules):
        """
        Inisialisasi dengan aturan berbentuk {if_conditions: then_conclusion}.
        :param rules: List of tuples [(set(if_conditions), then_conclusion)]
        """
        self.rules = rules

    def infer(self, facts):
        """
        Menjalankan forward chaining untuk menemukan kesimpulan berdasarkan fakta yang diketahui.
        :param facts: Set fakta yang diketahui.
        :return: Set kesimpulan yang dapat ditarik.
        """
        conclusions = set(facts)
        new_conclusion_found = True

        while new_conclusion_found:
            new_conclusion_found = False
            for conditions, conclusion in self.rules:
                if conditions.issubset(conclusions) and conclusion not in conclusions:
                    conclusions.add(conclusion)
                    new_conclusion_found = True

        return conclusions

# Contoh Penggunaan
if __name__ == "__main__":
    # Aturan sistem pakar (jika fakta ini diketahui, maka kesimpulan ini dapat ditarik)
    rules = [
        ({"Demam", "Batuk"}, "Flu"),
        ({"Flu", "Sakit Kepala"}, "Infeksi Virus"),
        ({"Bersin", "Mata Berair"}, "Alergi")
    ]

    # Fakta awal
    known_facts = {"Demam", "Batuk", "Sakit Kepala"}

    # Inisialisasi Forward Chaining
    fc = ForwardChaining(rules)
    inferred_facts = fc.infer(known_facts)

    print("🧠 Fakta & Kesimpulan AI:", inferred_facts)