class FuzzyLogic:
    """Implementasi Fuzzy Logic untuk menangani ketidakpastian dalam AI."""

    def __init__(self, membership_functions):
        """
        Inisialisasi dengan fungsi keanggotaan fuzzy.
        :param membership_functions: Dictionary {kategori: (min, max, fungsi)}
        """
        self.membership_functions = membership_functions

    def fuzzify(self, value):
        """
        Mengonversi nilai crisp menjadi derajat keanggotaan fuzzy.
        :param value: Nilai numerik yang akan difuzzifikasi.
        :return: Dictionary {kategori: derajat_keanggotaan}.
        """
        fuzzy_values = {}
        for category, (min_val, max_val, func) in self.membership_functions.items():
            fuzzy_values[category] = func(value, min_val, max_val)
        return fuzzy_values

    def defuzzify(self, fuzzy_values):
        """
        Mengubah nilai fuzzy kembali ke nilai numerik (crisp) menggunakan metode Centroid.
        :param fuzzy_values: Dictionary {kategori: derajat_keanggotaan}.
        :return: Nilai numerik hasil defuzzifikasi.
        """
        numerator = sum(value * weight for weight, value in fuzzy_values.items())
        denominator = sum(fuzzy_values.values())
        return numerator / denominator if denominator != 0 else 0

# Fungsi keanggotaan sederhana untuk Fuzzy Logic
def triangular_membership(x, a, b):
    """Fungsi keanggotaan segitiga untuk logika fuzzy."""
    if x <= a:
        return 0
    elif x >= b:
        return 1
    else:
        return (x - a) / (b - a)

# Contoh Penggunaan
if __name__ == "__main__":
    # Definisi fungsi keanggotaan
    membership_functions = {
        "Dingin": (0, 20, triangular_membership),
        "Normal": (15, 30, triangular_membership),
        "Panas": (25, 40, triangular_membership)
    }

    # Inisialisasi sistem logika fuzzy
    fuzzy_system = FuzzyLogic(membership_functions)

    # Masukkan nilai suhu
    suhu = 22

    # Fuzzifikasi
    fuzzy_values = fuzzy_system.fuzzify(suhu)
    print("🌡️ Hasil Fuzzifikasi:", fuzzy_values)

    # Defuzzifikasi
    crisp_value = fuzzy_system.defuzzify(fuzzy_values)
    print("🔢 Hasil Defuzzifikasi:", crisp_value)