import json
from core.algorithms.searching import SearchingAlgorithms
from core.algorithms.sorting import SortingAlgorithms
from core.decision_making.decision_tree import DecisionTree
from core.decision_making.bayesian import BayesianInference
from core.logical_ai.forward_chaining import ForwardChaining
from core.logical_ai.backward_chaining import BackwardChaining
from core.logical_ai.fuzzy_logic import FuzzyLogic
from knowledge_base.knowledge_manager import KnowledgeManager

class SAIBrain:
    """Otak utama AI - Mengontrol semua modul & Knowledge Base."""

    def __init__(self):
        self.load_config()
        self.init_ai_modules()
        self.knowledge_manager = KnowledgeManager()

    def load_config(self):
        """Memuat konfigurasi AI dari file `config.json`."""
        try:
            with open("config.json", "r") as file:
                self.config = json.load(file)
        except FileNotFoundError:
            print("⚠️ File `config.json` tidak ditemukan, menggunakan konfigurasi default.")
            self.config = {}

    def init_ai_modules(self):
        """Inisialisasi semua modul AI yang digunakan oleh SAI."""
        self.search_ai = SearchingAlgorithms()
        self.sort_ai = SortingAlgorithms()
        self.decision_tree = DecisionTree()
        self.bayesian_ai = BayesianInference({"Ya": 0.5, "Tidak": 0.5})
        self.forward_chaining = ForwardChaining([
            ({"Demam", "Batuk"}, "Flu"),
            ({"Flu", "Sakit Kepala"}, "Infeksi Virus")
        ])
        self.backward_chaining = BackwardChaining({
            "Flu": [{"Demam", "Batuk"}],
            "Infeksi Virus": [{"Flu", "Sakit Kepala"}]
        })
        self.fuzzy_logic = FuzzyLogic({
            "Dingin": (0, 20, lambda x, a, b: max(0, min(1, (b - x) / (b - a)))),
            "Normal": (15, 30, lambda x, a, b: max(0, min(1, (x - a) / (b - a)))),
            "Panas": (25, 40, lambda x, a, b: max(0, min(1, (x - a) / (b - a))))
        })

    def process_query(self, query):
        """Memproses pertanyaan pengguna dengan sistem AI dan Knowledge Base."""
        query = query.lower()

        # Cek apakah jawaban sudah ada di Knowledge Base
        stored_answers = self.knowledge_manager.load_data("ai_answers")
        if query in stored_answers:
            return f"🤖 (Dari Knowledge Base): {stored_answers[query]}"

        # Searching & Sorting
        if query.startswith("cari "):
            keyword = query[5:]
            result = f"Hasil pencarian: {self.search_ai.linear_search(['AI', 'ML', 'Data'], keyword)}"
            self.knowledge_manager.store_ai_answer(query, result)
            return result

        if query.startswith("urutkan "):
            data = list(map(int, query[8:].split()))
            result = f"Data terurut: {self.sort_ai.quick_sort(data)}"
            self.knowledge_manager.store_ai_answer(query, result)
            return result

        # Decision Making & Logical AI
        if query.startswith("apakah "):
            goal = query[7:].capitalize()
            result = f"Jawaban AI: {'✅ Ya' if self.backward_chaining.infer(goal, {'Demam', 'Batuk'}) else '❌ Tidak'}"
            self.knowledge_manager.store_ai_answer(query, result)
            return result

        if query.startswith("analisa "):
            fact = query[8:].capitalize()
            result = f"Hasil Analisis AI: {self.forward_chaining.infer({fact})}"
            self.knowledge_manager.store_ai_answer(query, result)
            return result

        if query.startswith("probabilitas "):
            event = query[12:].capitalize()
            likelihood = {"Ya": 0.7, "Tidak": 0.3}
            evidence = self.bayesian_ai.calculate_evidence(likelihood)
            posterior = self.bayesian_ai.update_posterior(likelihood, evidence)
            result = f"Probabilitas '{event}': {posterior.get(event, 'Tidak diketahui')}"
            self.knowledge_manager.store_ai_answer(query, result)
            return result

        if query.startswith("suhu "):
            suhu = int(query[5:])
            fuzzy_result = self.fuzzy_logic.fuzzify(suhu)
            result = f"Kategori suhu berdasarkan AI: {fuzzy_result}"
            self.knowledge_manager.store_ai_answer(query, result)
            return result

        return "⚠️ Perintah tidak dikenal."

# Contoh Penggunaan
if __name__ == "__main__":
    sai = SAIBrain()

    print("\n🤖 SAI Aktif! Masukkan pertanyaan Anda.")
    while True:
        user_input = input("🧠 Tanya AI: ")
        if user_input.lower() in ["exit", "keluar", "quit"]:
            print("👋 SAI dimatikan. Sampai jumpa!")
            break
        response = sai.process_query(user_input)
        print("🔍 Jawaban:", response)