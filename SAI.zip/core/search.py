import requests
import random
import time
from bs4 import BeautifulSoup
from core.knowledge import KnowledgeBase

class AIWebSearch:
    """Modul AI untuk pencarian web & ekstraksi data dari internet."""
    
    def __init__(self):
        self.knowledge_base = KnowledgeBase()
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
            "Mozilla/5.0 (X11; Linux x86_64)"
        ]
    
    def google_search(self, query):
        """Melakukan pencarian di Google dan mengembalikan hasil terbaik."""
        search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        headers = {"User-Agent": random.choice(self.user_agents)}

        try:
            response = requests.get(search_url, headers=headers, timeout=10)
            if response.status_code == 200:
                return self.extract_google_results(response.text)
            else:
                return "⚠️ Gagal menghubungi Google."
        except requests.exceptions.RequestException as e:
            return f"⚠️ Error: {e}"

    def extract_google_results(self, html):
        """Menarik hasil pencarian Google & mengembalikan link terbaik."""
        soup = BeautifulSoup(html, "html.parser")
        results = []
        
        for item in soup.find_all("h3"):
            title = item.text
            link = item.find_parent("a")["href"] if item.find_parent("a") else ""
            if title and link:
                results.append(f"{title} - {link}")

        return results[:5] if results else ["Tidak ada hasil ditemukan."]

    def scrape_page(self, url):
        """Mengambil isi teks dari halaman web."""
        headers = {"User-Agent": random.choice(self.user_agents)}
        
        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, "html.parser")
                paragraphs = soup.find_all("p")
                return " ".join([p.text for p in paragraphs[:5]])  # Ambil 5 paragraf pertama
            else:
                return "⚠️ Gagal mengambil data dari halaman."
        except requests.exceptions.RequestException as e:
            return f"⚠️ Error: {e}"

    def search_and_store(self, query):
        """Mencari informasi di Google, mengekstrak data, dan menyimpannya ke knowledge base."""
        results = self.google_search(query)
        if not results:
            return "Tidak ada hasil ditemukan."

        top_result = results[0].split(" - ")[-1]  # Ambil URL terbaik
        page_content = self.scrape_page(top_result)
        self.knowledge_base.save_knowledge(query, page_content)
        
        return f"✅ AI telah menyimpan hasil pencarian tentang: {query}"

# Contoh penggunaan
if __name__ == "__main__":
    ai_search = AIWebSearch()
    user_query = input("🔍 Masukkan kata kunci untuk dicari AI: ")
    print(ai_search.search_and_store(user_query))