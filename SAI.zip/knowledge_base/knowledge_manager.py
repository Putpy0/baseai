import json
import os

class KnowledgeManager:
    """Sistem manajemen Knowledge Base untuk AI SAI."""

    def __init__(self, data_dir="knowledge_base/data"):
        self.data_dir = data_dir
        self.files = {
            "facts": "facts.json",
            "search_logs": "search_logs.json",
            "user_queries": "user_queries.json",
            "ai_answers": "ai_answers.json",
            "trends": "trends.json"
        }
        self.ensure_data_files()

    def ensure_data_files(self):
        """Memastikan semua file data tersedia, jika tidak, buat file baru."""
        os.makedirs(self.data_dir, exist_ok=True)
        for key, filename in self.files.items():
            file_path = os.path.join(self.data_dir, filename)
            if not os.path.exists(file_path):
                with open(file_path, "w") as f:
                    json.dump({}, f)

    def load_data(self, file_key):
        """Membaca data dari file JSON."""
        file_path = os.path.join(self.data_dir, self.files[file_key])
        with open(file_path, "r") as f:
            return json.load(f)

    def save_data(self, file_key, data):
        """Menyimpan data ke file JSON."""
        file_path = os.path.join(self.data_dir, self.files[file_key])
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)

    def add_fact(self, fact, source="AI"):
        """Menambahkan fakta baru ke knowledge base."""
        data = self.load_data("facts")
        data[fact] = {"source": source}
        self.save_data("facts", data)

    def log_search(self, query, result):
        """Menyimpan riwayat pencarian yang dilakukan AI."""
        data = self.load_data("search_logs")
        data[query] = result
        self.save_data("search_logs", data)

    def store_user_query(self, query):
        """Merekam pertanyaan user untuk analisis pola."""
        data = self.load_data("user_queries")
        data[len(data) + 1] = query
        self.save_data("user_queries", data)

    def store_ai_answer(self, query, answer):
        """Menyimpan jawaban AI agar bisa digunakan kembali."""
        data = self.load_data("ai_answers")
        data[query] = answer
        self.save_data("ai_answers", data)

# Contoh Penggunaan
if __name__ == "__main__":
    kb = KnowledgeManager()
    kb.add_fact("Air mendidih pada suhu 100°C")
    kb.log_search("Siapa penemu AI?", "John McCarthy")
    kb.store_user_query("Apakah AI bisa berpikir?")
    kb.store_ai_answer("Apa itu AI?", "AI adalah kecerdasan buatan yang dibuat oleh manusia.")

    print("📚 Knowledge Base AI diperbarui!")