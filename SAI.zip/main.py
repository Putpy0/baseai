import os
import json
from core.sai_brain import SAIBrain
from core.search import AIWebSearch
from core.learning import AILearning

class SAI:
    """Sistem AI Utama (Super AI - SAI)."""

    def __init__(self):
        self.ai_brain = SAIBrain()
        self.web_search = AIWebSearch()
        self.ai_learning = AILearning()
        self.load_config()

    def load_config(self):
        """Memuat konfigurasi dari file `config.json`."""
        try:
            with open("config.json", "r") as file:
                self.config = json.load(file)
        except FileNotFoundError:
            print("⚠️ File `config.json` tidak ditemukan, menggunakan konfigurasi default.")
            self.config = {}

    def process_command(self, command):
        """Memproses perintah pengguna."""
        if command.lower().startswith("tanya "):
            question = command[6:]
            print("\n💡 Jawaban AI:\n", self.ai_brain.ask(question))
        elif command.lower().startswith("cari "):
            query = command[5:]
            print("\n🌍 Hasil Pencarian Web:\n", self.web_search.search_and_store(query))
        elif command.lower().startswith("latih "):
            topic = command[6:]
            print("\n📚 AI sedang belajar dari berita terbaru...\n", self.ai_learning.update_knowledge_from_news(topic))
        elif command.lower() in ["keluar", "exit", "quit"]:
            print("\n👋 Terima kasih telah menggunakan SAI. Sampai jumpa!\n")
            exit()
        else:
            print("\n⚠️ Perintah tidak dikenal. Gunakan `tanya`, `cari`, atau `latih`.")

    def run(self):
        """Menjalankan SAI dalam mode terminal (CLI)."""
        print("\n🤖 Selamat datang di SAI - Super AI!\n")
        while True:
            command = input("🧠 Masukkan perintah (tanya/cari/latih/keluar): ")
            self.process_command(command)

# Jalankan SAI
if __name__ == "__main__":
    sai = SAI()
    sai.run()