from fastapi import FastAPI
from pydantic import BaseModel
from core.sai_brain import SAIBrain

app = FastAPI()
sai = SAIBrain()

class QueryRequest(BaseModel):
    query: str

@app.get("/")
def home():
    return {"message": "SAI API is running!"}

@app.post("/ask")
def ask_sai(request: QueryRequest):
    """Endpoint untuk mengajukan pertanyaan ke SAI."""
    response = sai.process_query(request.query)
    return {"response": response}

# Jalankan API dengan: uvicorn server:app --host 0.0.0.0 --port 8000
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)