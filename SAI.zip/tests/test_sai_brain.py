import unittest
from sai_core.sai_brain import SAIBrain

class TestSAIBrain(unittest.TestCase):
    """Unit test untuk sistem utama SAI."""

    def setUp(self):
        """Inisialisasi sebelum setiap test."""
        self.sai = SAIBrain()

    def test_searching(self):
        """Menguji pencarian AI."""
        result = self.sai.process_query("cari AI")
        self.assertIn("Hasil pencarian", result)

    def test_sorting(self):
        """Menguji pengurutan AI."""
        result = self.sai.process_query("urutkan 3 1 2")
        self.assertIn("Data terurut", result)

    def test_decision_tree(self):
        """Menguji Decision Tree AI."""
        result = self.sai.process_query("apakah Flu?")
        self.assertIn("Jawaban AI", result)

    def test_bayesian_inference(self):
        """Menguji Bayesian Inference AI."""
        result = self.sai.process_query("probabilitas Flu")
        self.assertIn("Probabilitas", result)

    def test_fuzzy_logic(self):
        """Menguji sistem Fuzzy Logic AI."""
        result = self.sai.process_query("suhu 22")
        self.assertIn("Kategori suhu", result)

    def test_invalid_command(self):
        """Menguji perintah yang tidak dikenal."""
        result = self.sai.process_query("perintah tidak dikenal")
        self.assertEqual(result, "⚠️ Perintah tidak dikenal.")

if __name__ == "__main__":
    unittest.main()